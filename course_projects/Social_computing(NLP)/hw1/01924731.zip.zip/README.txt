﻿    1. In the first block of the code, we created the API.
    2. In the next block, we collected 1000 tweets using #BTC (bitcoin) and #ETH (Ethereum). Then, we added each of the tweets to the JSON file. We created a loop to check whether tweet text has more than five words. If that was the case, we added the tweet to the 300 samples that we needed. We also extracted some of the features of the tweets and stored them in a data frame. Finally, we created a CSV file for the data frame.
    3. In the next block, we repeated all the processes in block #2 using the streaming tweets
       
